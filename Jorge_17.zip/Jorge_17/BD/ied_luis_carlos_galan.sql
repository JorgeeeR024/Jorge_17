-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-11-2024 a las 02:41:50
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ied_luis_carlos_galan`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificaciones`
--

CREATE TABLE `calificaciones` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `materia` varchar(100) NOT NULL,
  `periodo1` int(11) NOT NULL,
  `periodo2` int(11) NOT NULL,
  `periodo3` int(11) NOT NULL,
  `periodo4` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE `cursos` (
  `id` int(11) NOT NULL,
  `nombre_grado` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes`
--

CREATE TABLE `estudiantes` (
  `id_estudiantes` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo_documento` varchar(25) NOT NULL,
  `numero_documento` bigint(20) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inscripciones`
--

CREATE TABLE `inscripciones` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `grado` varchar(10) DEFAULT NULL,
  `acudiente` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inscripciones`
--

INSERT INTO `inscripciones` (`id`, `nombre`, `grado`, `acudiente`, `telefono`, `email`, `fecha`) VALUES
(1, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:04:51'),
(2, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:15:34'),
(3, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:15:53'),
(4, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:18:23'),
(5, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:20:56'),
(6, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:21:06'),
(7, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:21:10'),
(8, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:21:21'),
(9, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:23:02'),
(10, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 17:25:00'),
(11, 'Jorge Eliecer Ramirez Obando', '6', 'Jorge Ramirez', '3104215281', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-24 20:37:29'),
(12, 'Jorge Eliecer Ramirez Obando', '6', 'Jorge Ramirez', '3104215281', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-25 17:37:29'),
(13, 'Jorge Eliecer Ramirez Obando', '6', 'jorge eliecer ramirez gaitan', '3183967060', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-26 18:49:36'),
(14, 'Jorge Eliecer Ramirez Obando', '6', 'Jorge Ramirez', '3104215281', 'ramirezobandojorgeeliecer@gmail.com', '2024-11-26 21:26:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materias`
--

CREATE TABLE `materias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas`
--

CREATE TABLE `notas` (
  `NotasId` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Grado` varchar(50) NOT NULL,
  `Materia` varchar(100) NOT NULL,
  `id_estudiantes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `notas`
--

INSERT INTO `notas` (`NotasId`, `Nombre`, `Grado`, `Materia`, `id_estudiantes`) VALUES
(37, 'catalina', '7', 'cuantica', 0),
(38, 'catalina', '7', 'cuantica', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `periodos`
--

CREATE TABLE `periodos` (
  `PeriodosId` int(11) NOT NULL,
  `Periodo1` int(100) NOT NULL,
  `Periodo2` int(50) NOT NULL,
  `Periodo3` int(100) NOT NULL,
  `Periodo4` int(100) NOT NULL,
  `id_estudiantes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `periodos`
--

INSERT INTO `periodos` (`PeriodosId`, `Periodo1`, `Periodo2`, `Periodo3`, `Periodo4`, `id_estudiantes`) VALUES
(37, 80, 80, 80, 80, 37),
(38, 80, 80, 80, 80, 38);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tpdoc` varchar(50) NOT NULL,
  `numero_doc` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `registro`
--

INSERT INTO `registro` (`id`, `nombre`, `tpdoc`, `numero_doc`, `email`, `password`, `fecha_registro`) VALUES
(29, 'Jorge Eliecer Ramirez Obando ', 'Cédula de ciudadanía', 1054547490, 'ramirezobandojorgeeliecer@gmail.com', '123456', '2024-11-29 13:26:43');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD PRIMARY KEY (`id_estudiantes`);

--
-- Indices de la tabla `inscripciones`
--
ALTER TABLE `inscripciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `materias`
--
ALTER TABLE `materias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notas`
--
ALTER TABLE `notas`
  ADD PRIMARY KEY (`NotasId`);

--
-- Indices de la tabla `periodos`
--
ALTER TABLE `periodos`
  ADD PRIMARY KEY (`PeriodosId`);

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  MODIFY `id_estudiantes` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `inscripciones`
--
ALTER TABLE `inscripciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `materias`
--
ALTER TABLE `materias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `notas`
--
ALTER TABLE `notas`
  MODIFY `NotasId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de la tabla `periodos`
--
ALTER TABLE `periodos`
  MODIFY `PeriodosId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de la tabla `registro`
--
ALTER TABLE `registro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
