from flask import Flask, request, jsonify
import random

app = Flask(__name__)

# 📚 Base de conocimiento del chatbot
knowledge_base = {
    "saludos": {
        "patterns": ["hola", "buenos días", "buenas tardes", "buenas noches", "qué tal"],
        "responses": [
            "¡Hola! Soy el asistente de InsSchool. ¿En qué puedo ayudarte?",
            "¡Buen día! ¿Cómo puedo asistirte hoy?"
        ]
    },
    "despedidas": {
        "patterns": ["adiós", "hasta luego", "nos vemos", "chao"],
        "responses": [
            "¡Hasta luego! Recuerda que estoy aquí para ayudarte.",
            "¡Que tengas un buen día! Si necesitas algo más, no dudes en preguntar."
        ]
    },
    "informacion_institucion": {
        "patterns": ["información del colegio", "qué es la ied luis carlos galán", "historia del colegio"],
        "responses": [
            "La IED Luis Carlos Galán es una institución educativa comprometida con la formación integral de sus estudiantes. Nuestro lema es: 'El pasado es historia, el presente es pasado y el futuro es ahora'."
        ]
    },
    "contacto": {
        "patterns": ["cómo contactarlos", "dónde están ubicados", "teléfono", "dirección"],
        "responses": [
            "Puedes contactarnos en la dirección: [Dirección de la institución], teléfono: (123) 456-7890, o correo electrónico: info@insschool.com"
        ]
    },
    "servicios": {
        "patterns": ["qué servicios ofrecen", "qué ofrece el colegio", "programas académicos"],
        "responses": [
            "Ofrecemos educación de calidad desde preescolar hasta media técnica, con énfasis en [especificar énfasis de la institución]."
        ]
    },
    "inscripciones": {
        "patterns": ["cómo me inscribo", "requisitos para inscripción", "proceso de matrícula"],
        "responses": [
            "El proceso de inscripción requiere: 1. Documento de identidad, 2. Fotocopia del seguro médico, 3. Certificados de años anteriores. Puedes iniciar el proceso en nuestra plataforma InsSchool."
        ]
    },
    "default": {
        "responses": [
            "Lo siento, no entendí tu pregunta. ¿Podrías reformularla?",
            "No estoy seguro de cómo responder eso. ¿Quieres información sobre nuestros servicios, contacto o inscripciones?"
        ]
    }
}

# 🤖 Función que busca la mejor respuesta según el mensaje
def get_response(user_input):
    user_input = user_input.lower().strip()
    
    for intent, data in knowledge_base.items():
        if intent == "default":
            continue
        
        if any(pattern in user_input for pattern in data["patterns"]):
            return random.choice(data["responses"])
    
    return random.choice(knowledge_base["default"]["responses"])

# 📥 Ruta que recibe mensajes vía POST
@app.route('/chatbot', methods=['POST'])
def chatbot():
    data = request.get_json()
    user_message = data.get('mensaje', '')
    
    if not user_message:
        return jsonify({"error": "Mensaje vacío"}), 400
    
    bot_response = get_response(user_message)
    return jsonify({"response": bot_response})

# 🚀 Inicia el servidor en modo debug
if __name__ == '__main__':
    app.run(debug=True, port=5000)
