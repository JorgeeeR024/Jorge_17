<?php
session_start();

// Verificar si el usuario es Docente (rol 2)
if (!isset($_SESSION['user_id']) || ($_SESSION['id_rol'] ?? 0) != 2) {
    header("Location: login.html");
    exit;
}

$nombre_rol = "Docente"; // Nombre fijo para mostrar
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/InsSchool.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Docente - InsSchool</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <!-- Navbar para Docente -->
    <nav class="navbar">
        <a href="school_docente.php" class="logo">InsSchool</a>
        <div class="hamburger">
            <i class="fas fa-bars"></i>
        </div>
        <ul class="nav-links">
            <li><a href="ver_estudiantes.php">Ver Estudiantes</a></li>
            <li><a href="subir_notas.php">Subir Notas</a></li>
            <li><a href="ver_cursos.php">Mis Cursos</a></li>
            <li><a href="reportes_docente.php">Reportes Académicos</a></li>
            <li class="user-info">Bienvenido, <strong><?php echo $nombre_rol; ?></strong></li>
            <li><a href="logout.php" class="logout-btn">Cerrar sesión</a></li>
        </ul>
    </nav>

    <header>
        <div class="header-content">
            <h1>Panel del Docente</h1>
            <p>Gestión académica y seguimiento de estudiantes</p>
            <div class="header-buttons">
                <a href="editar_nota.php" class="btn">Subir Notas</a>
                <a href="ver_estudiantes.php" class="btn btn-outline">Ver Estudiantes</a>
            </div>
        </div>
    </header>

    <section class="welcome-section">
        <h2>Herramientas del Docente</h2>
        <p>
            Desde aquí puedes gestionar tus cursos, evaluar estudiantes y generar reportes académicos para el seguimiento educativo.
        </p>
    </section>

    <div class="content">
        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/gestion_notas.jpg" alt="Notas">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Gestión de Notas</h3>
                <p class="card-text">Evalúa y registra el desempeño académico de tus estudiantes.</p>
                <a href="subir_notas.php" class="card-btn">LCG</a>
            </div>
        </div>

        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/lista.png" alt="Estudiantes">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Lista de Estudiantes</h3>
                <p class="card-text">Consulta los estudiantes inscritos a tus cursos.</p>
                <a href="ver_estudiantes.php" class="card-btn">LCG</a>
            </div>
        </div>

        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/cursos.jpg" alt="Cursos">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Mis Cursos</h3>
                <p class="card-text">Administra los cursos que tienes asignados.</p>
                <a href="ver_cursos.php" class="card-btn">LCG</a>
            </div>
        </div>
    </div>

    <section class="stats-section">
        <div class="stats-container">
            <div class="stat-item">
                <div class="stat-number" id="cursos-asignados">5</div>
                <div class="stat-text">Cursos asignados</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="estudiantes-total">200</div>
                <div class="stat-text">Estudiantes a cargo</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="tareas-pendientes">3</div>
                <div class="stat-text">Tareas por calificar</div>
            </div>
        </div>
    </section>

    <script>
        // Ejemplo: cargar datos reales en el futuro
        fetch('get_stats_docente.php')
            .then(res => res.json())
            .then(data => {
                document.getElementById('cursos-asignados').textContent = data.cursos;
                document.getElementById('estudiantes-total').textContent = data.estudiantes;
                document.getElementById('tareas-pendientes').textContent = data.tareas;
            });
    </script>

</body>
</html>
