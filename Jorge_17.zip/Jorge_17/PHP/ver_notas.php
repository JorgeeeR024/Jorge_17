<?php
include('conexion.php');

// Obtener lista de cursos
$cursos = $conexion->query("SELECT id_curso, nombre_grado FROM cursos");
$id_curso = $_GET['id_curso'] ?? null;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Asignación de Notas</title>
    <link rel="stylesheet" href="../CSS/crud.css">
    
</head>
<body>
    <h1>Asignación de Notas</h1>
    
    <!-- Selector de curso -->
    <form method="GET">
        <label>Seleccione el grado:</label>
        <select name="id_curso" onchange="this.form.submit()" required>
            <option value=""> Seleccione! </option>
            <?php while($curso = $cursos->fetch_assoc()): ?>
                <option value="<?= $curso['id_curso'] ?>"
                    <?= $id_curso == $curso['id_curso'] ? 'selected' : '' ?>>
                    <?= $curso['nombre_grado'] ?>
                </option>
            <?php endwhile; ?>
        </select>
    </form>

    <?php if($id_curso): ?>
    <div class="container">
        <!-- Panel de estudiantes -->
        <div class="panel">
            <h2>Estudiantes</h2>
            <?php
            $estudiantes = $conexion->query("SELECT id, nombre FROM registro WHERE id_curso = $id_curso");
            
            while($estudiante = $estudiantes->fetch_assoc()):
                $active = ($_GET['id_estudiante'] ?? 0) == $estudiante['id'] ? 'background: #e6ffe6;' : '';
            ?>
                <div style="padding: 8px; margin: 4px 0; cursor: pointer; <?= $active ?>"
                     onclick="location.href='ver_notas.php?id_curso=<?= $id_curso ?>&id_estudiante=<?= $estudiante['id'] ?>'">
                    <?= $estudiante['nombre'] ?>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Panel de asignación de notas -->
        <div class="panel">
            <?php if(isset($_GET['id_estudiante'])): ?>
                <?php
                $id_estudiante = intval($_GET['id_estudiante']);
                $estudiante = $conexion->query("SELECT nombre FROM registro WHERE id = $id_estudiante")->fetch_assoc();
                $materias = $conexion->query("SELECT id_materia, nombre FROM materias WHERE id_curso = $id_curso");
                ?>
                
                <h2>Asignar notas a: <?= $estudiante['nombre'] ?></h2>
                
                <form action="guardar_notas.php" method="POST">
                    <input type="hidden" name="id_curso" value="<?= $id_curso ?>">
                    <input type="hidden" name="id_estudiante" value="<?= $id_estudiante ?>">
                    
                    <label>Materia:</label>
                    <select name="id_materia" required>
                        <option value="">-- Seleccione --</option>
                        <?php while($materia = $materias->fetch_assoc()): ?>
                            <option value="<?= $materia['id_materia'] ?>"><?= $materia['nombre'] ?></option>
                        <?php endwhile; ?>
                    </select>
                    
                    <label>Periodo 1:</label>
                    <input type="number" name="periodo1" step="0.1" min="0" max="10">
                    
                    <label>Periodo 2:</label>
                    <input type="number" name="periodo2" step="0.1" min="0" max="10">
                    
                    <label>Periodo 3:</label>
                    <input type="number" name="periodo3" step="0.1" min="0" max="10">
                    
                    <label>Periodo 4:</label>
                    <input type="number" name="periodo4" step="0.1" min="0" max="10">
                    
                    <button type="submit">Guardar Notas</button>
                </form>
                
                <!-- Mostrar notas existentes -->
                <h3>Notas Registradas</h3>
                <table>
                    <tr>
                        <th>Materia</th>
                        <th>P1</th>
                        <th>P2</th>
                        <th>P3</th>
                        <th>P4</th>
                        <th>Acciones</th>
                    </tr>
                    <?php
                    $notas = $conexion->query("
                        SELECT c.id, m.nombre AS materia, c.periodo1, c.periodo2, c.periodo3, c.periodo4
                        FROM calificaciones c
                        JOIN materias m ON c.id_materia = m.id_materia
                        WHERE c.id_estudiante = $id_estudiante AND c.id_curso = $id_curso
                        ORDER BY m.nombre
                    ");
                    
                    while($nota = $notas->fetch_assoc()):
                    ?>
                        <tr>
                            <td><?= $nota['materia'] ?></td>
                            <td><?= $nota['periodo1'] ?? '-' ?></td>
                            <td><?= $nota['periodo2'] ?? '-' ?></td>
                            <td><?= $nota['periodo3'] ?? '-' ?></td>
                            <td><?= $nota['periodo4'] ?? '-' ?></td>
                            <td>
                                <a href="editar_nota.php?id=<?= $nota['id'] ?>" class="action-btn edit-btn" title="Editar">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M3 17.25V21h3.75l11.06-11.06-3.75-3.75L3 17.25zm17.71-10.04c.39-.39.39-1.02 0-1.41l-2.54-2.54a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                                    </svg>
                                </a>
                                
                                <a href="eliminar_nota.php?id=<?= $nota['id'] ?>&id_curso=<?= $id_curso ?>&id_estudiante=<?= $id_estudiante ?>" 
                                   class="action-btn delete-btn" 
                                   title="Eliminar"
                                   onclick="return confirm('¿Está seguro de eliminar estas notas?')">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                                    </svg>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            <?php else: ?>
                <h2>Seleccione un estudiante</h2>
                <p>Haga clic en un estudiante del panel izquierdo para asignar notas.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</body>
</html>