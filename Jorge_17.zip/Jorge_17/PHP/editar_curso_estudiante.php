<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['user_id']) || $_SESSION['id_rol'] != 1) {
    header("Location: ../html/login.html");
    exit;
}

$id_estudiante = intval($_GET['id']);
$estudiante = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT * FROM registro WHERE id = $id_estudiante"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_curso = intval($_POST['id_curso']);
    
    if ($_POST['accion'] == 'asignar') {
        mysqli_query($conexion, 
            "INSERT IGNORE INTO estudiantes_cursos (id_estudiante, id_curso) 
             VALUES ($id_estudiante, $id_curso)");
        $_SESSION['mensaje'] = "Curso asignado";
    } 
    elseif ($_POST['accion'] == 'remover') {
        mysqli_query($conexion, 
            "DELETE FROM estudiantes_cursos 
             WHERE id_estudiante = $id_estudiante AND id_curso = $id_curso");
        $_SESSION['mensaje'] = "Curso removido";

    }
    header("Location: editar_curso_estudiante.php?id=$id_estudiante");
    exit;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/editar_cursos.css">
    <title>Gestionar Cursos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <div class="container">
        <a href="school_admi.php"><i class="fas fa-arrow-left"></i> Volver</a> 
</div>

        <h1>Cursos de <?= htmlspecialchars($estudiante['nombre']) ?></h1>
        
        <?php if (isset($_SESSION['mensaje'])): ?>
            <p style="color:green"><?= $_SESSION['mensaje'] ?></p>
            <?php unset($_SESSION['mensaje']); ?>
        <?php endif; ?>

        <div class="grid">
            <!-- Cursos Asignados -->
            <div>
                <h2><i class="fas fa-check"></i> Cursos Actuales</h2>
                <?php
                $cursos = mysqli_query($conexion, 
                    "SELECT c.id_curso, c.nombre_grado 
                     FROM cursos c
                     JOIN estudiantes_cursos ec ON c.id_curso = ec.id_curso
                     WHERE ec.id_estudiante = $id_estudiante");
                
                if (mysqli_num_rows($cursos) > 0) {
                    while($curso = mysqli_fetch_assoc($cursos)) {
                        echo '
                        <div class="curso">
                            '.htmlspecialchars($curso['nombre_grado']).'
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="accion" value="remover">
                                <input type="hidden" name="id_curso" value="'.$curso['id_curso'].'">
                                <button type="submit" onclick="return confirm(\'¿Retirar?\')">
                                    <i class="fas fa-times"></i> Remover
                                </button>
                            </form>
                        </div>';
                    }
                } else {
                    echo '<p>No tiene cursos asignados</p>';
                }
                ?>
            </div>

            <!-- Asignar Cursos -->
            <div>
                <h2><i class="fas fa-plus"></i> Asignar Curso</h2>
                <form method="POST">
                    <input type="hidden" name="accion" value="asignar">
                    <select name="id_curso" required>
                        <option value="">Seleccionar curso</option>
                        <?php
                        $cursos_disponibles = mysqli_query($conexion, 
                            "SELECT * FROM cursos 
                             WHERE id_curso NOT IN (
                                 SELECT id_curso FROM estudiantes_cursos 
                                 WHERE id_estudiante = $id_estudiante
                             )");
                        
                        while($curso = mysqli_fetch_assoc($cursos_disponibles)) {
                            echo '<option value="'.$curso['id_curso'].'">'
                                .htmlspecialchars($curso['nombre_grado'])
                                .'</option>';
                        }
                        ?>
                    </select>
                    <button type="submit"><i class="fas fa-save"></i> Asignar</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>