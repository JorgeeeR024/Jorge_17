<?php
header('Content-Type: application/json');

include 'conexion.php';

if (!$conexion) {
    die(json_encode(['error' => 'Error de conexión: ' . mysqli_connect_error()]));
}

// Consulta modificada
$query = "SELECT MONTH(fecha_registro) AS mes, COUNT(*) AS total 
          FROM registro 
          WHERE fecha_registro IS NOT NULL 
          GROUP BY MONTH(fecha_registro) 
          ORDER BY mes";

$result = mysqli_query($conexion, $query);

if (!$result) {
    die(json_encode(['error' => 'Error en la consulta: ' . mysqli_error($conexion)]));
}

// Verificar si hay datos
if (mysqli_num_rows($result) === 0) {
    die(json_encode(['error' => 'No hay registros con fechas']));
}

$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode($data);
mysqli_close($conexion);
?>