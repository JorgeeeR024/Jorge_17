<?php
include('conexion.php');

$id = intval($_GET['id']);
$id_curso = intval($_GET['id_curso']);
$id_estudiante = intval($_GET['id_estudiante']);

// Eliminar la nota
$conexion->query("DELETE FROM calificaciones WHERE id = $id");

// Redireccionar de vuelta a la página de notas
header("Location: ver_notas.php?id_curso=$id_curso&id_estudiante=$id_estudiante");
exit();
?>