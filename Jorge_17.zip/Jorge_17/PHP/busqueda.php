<?php
include 'conexion.php';

$busqueda = $_POST['busqueda'] ?? '';

$sql = "SELECT nombre, email FROM registro WHERE nombre LIKE '%$busqueda%' OR id = '$busqueda'";
$resultado = mysqli_query($conexion, $sql);

$datos = [];

if ($resultado && mysqli_num_rows($resultado) > 0) {
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $datos[] = $fila;
    }
}

mysqli_close($conexion);
echo json_encode($datos);
?>
