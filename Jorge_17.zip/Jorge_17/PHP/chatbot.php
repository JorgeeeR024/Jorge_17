<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// 1. Verificar conectividad primero
if (!@fsockopen("api.openai.com", 443, $errno, $errstr, 10)) {
    echo json_encode([
        "error" => "Error de conexión con OpenAI",
        "details" => "$errstr ($errno)",
        "solution" => "El servidor no puede conectarse a api.openai.com. Verifica firewall/red."
    ]);
    exit;
}

// 2. Configuración de API (USAR VARIABLE DE ENTORNO EN PRODUCCIÓN)
$api_key = "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"; // ¡REEMPLAZA ESTO!

// 3. Validar método y datos
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Método no permitido"]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data || empty($data['mensaje'])) {
    http_response_code(400);
    echo json_encode(["error" => "Mensaje inválido"]);
    exit;
}

// 4. Configurar solicitud a OpenAI con verificación SSL
$ch = curl_init();
// Intenta con estas opciones adicionales:
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.openai.com/v1/models");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer TU_API_KEY"
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
echo curl_exec($ch);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // SOLO PARA PRUEBAS
curl_setopt($ch, CURLOPT_PROXY, "tu-proxy-si-es-necesario:puerto");
curl_setopt_array($ch, [
    CURLOPT_URL => "https://api.openai.com/v1/chat/completions",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode([
        "model" => "gpt-3.5-turbo",
        "messages" => [
            ["role" => "system", "content" => "Eres un asistente útil."],
            ["role" => "user", "content" => $data['mensaje']]
        ],
        "temperature" => 0.7
    ]),
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "Authorization: Bearer $api_key"
    ],
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => true, // Importante para seguridad
    CURLOPT_SSL_VERIFYHOST => 2
]);

// 5. Ejecutar y manejar respuesta
$response = curl_exec($ch);

if (curl_errno($ch)) {
    http_response_code(502);
    echo json_encode([
        "error" => "Error en la conexión con OpenAI",
        "curl_error" => curl_error($ch),
        "curl_errno" => curl_errno($ch)
    ]);
    curl_close($ch);
    exit;
}

$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// 6. Validar respuesta HTTP
if ($httpCode !== 200) {
    http_response_code($httpCode);
    echo json_encode([
        "error" => "Error en la API de OpenAI",
        "http_code" => $httpCode,
        "response" => $response
    ]);
    exit;
}

// 7. Devolver respuesta exitosa
echo $response;
?>