<?php
session_start(); // Inicia la sesión si no está iniciada
session_destroy(); // Destruye la sesión actual
header("Location: ../html/login.html"); // Redirige a la página de inicio de sesión
exit; // Asegura que el script se detenga aquí
?>
