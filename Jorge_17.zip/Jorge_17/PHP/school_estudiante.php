<?php
session_start();

// Verificar si el usuario es Estudiante (rol 1)
if (!isset($_SESSION['user_id']) || ($_SESSION['id_rol'] ?? 0) != 3) {
    header("Location: login.html");
    exit;
}

$nombre_rol = "Estudiante"; // Nombre que se muestra en el panel
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/InsSchool.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Estudiante - InsSchool</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <!-- Barra de navegación para Estudiante -->
    <nav class="navbar">
        <a href="school_estudiante.php" class="logo">InsSchool</a>
        <div class="hamburger">
            <i class="fas fa-bars"></i>
        </div>
        <ul class="nav-links">
            <li><a href="ver_materias.php">Mis Materias</a></li>
            <li><a href="ver_notas.php">Mis Notas</a></li>
            <li><a href="horario.php">Mi Horario</a></li>
            <li><a href="ver_docentes.php">Mis Profesores</a></li>
            <li class="user-info">Bienvenido, <strong><?php echo $nombre_rol; ?></strong></li>
            <li><a href="logout.php" class="logout-btn">Cerrar sesión</a></li>
        </ul>
    </nav>

    <!-- Header con mensaje específico para Estudiante -->
    <header>
        <div class="header-content">
            <h1>Panel del Estudiante</h1>
            <p>Tu espacio para el aprendizaje y el progreso 📘✨</p>
            <div class="header-buttons">
                <a href="ver_materias.php" class="btn">Ver Materias</a>
                <a href="ver_notas.php" class="btn btn-outline">Ver Notas</a>
            </div>
        </div>
    </header>

    <!-- Sección de bienvenida -->
    <section id="about" class="welcome-section">
        <h2>Bienvenido al sistema académico</h2>
        <p>
            Desde aquí podrás ver tus materias, consultar tus notas y conocer a tus docentes. ¡A romperla en clase! 💪🎓
        </p>
    </section>

    <!-- Tarjetas para acciones rápidas -->
    <div class="content">
        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/est1.jpg" alt="Materias">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Mis Materias</h3>
                <p class="card-text">Consulta las materias en las que estás inscrito.</p>
                <a href="ver_materias.php" class="card-btn">Entrar</a>
            </div>
        </div>

        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/est2.jpg" alt="Notas">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Mis Notas</h3>
                <p class="card-text">Revisa tu rendimiento académico.</p>
                <a href="ver_notas.php" class="card-btn">Consultar</a>
            </div>
        </div>

        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/est3.jpg" alt="Horario">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Mi Horario</h3>
                <p class="card-text">Visualiza tu horario semanal de clases.</p>
                <a href="horario.php" class="card-btn">Ver</a>
            </div>
        </div>
    </div>

    <!-- Sección de estadísticas simplificada -->
    <section class="stats-section">
        <div class="stats-container">
            <div class="stat-item">
                <div class="stat-number" id="materias-activas">5</div>
                <div class="stat-text">Materias activas</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="profes-asignados">4</div>
                <div class="stat-text">Profesores asignados</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="promedio-general">4.5</div>
                <div class="stat-text">Promedio general</div>
            </div>
        </div>
    </section>

    <!-- Scripts para cargar datos -->
    <script>
        // Datos simulados, puedes reemplazar con llamada a PHP si lo necesitas
        fetch('get_estadisticas_estudiante.php')
            .then(response => response.json())
            .then(data => {
                document.getElementById('materias-activas').textContent = data.materias;
                document.getElementById('profes-asignados').textContent = data.profesores;
                document.getElementById('promedio-general').textContent = data.promedio;
            });
    </script>

</body>
</html>
