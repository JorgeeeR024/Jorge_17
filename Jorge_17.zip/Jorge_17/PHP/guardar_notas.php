<?php
include('conexion.php');

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_curso = intval($_POST['id_curso']);
    $id_estudiante = intval($_POST['id_estudiante']);
    $id_materia = intval($_POST['id_materia']);
    $periodo1 = floatval($_POST['periodo1'] ?? 0);
    $periodo2 = floatval($_POST['periodo2'] ?? 0);
    $periodo3 = floatval($_POST['periodo3'] ?? 0);
    $periodo4 = floatval($_POST['periodo4'] ?? 0);
    
    // Verificar si ya existe registro para esta materia y estudiante
    $existe = $conexion->query("SELECT id FROM calificaciones 
                               WHERE id_estudiante = $id_estudiante 
                               AND id_materia = $id_materia")->num_rows;
    
    if($existe > 0) {
        // Actualizar si ya existe
        $stmt = $conexion->prepare("UPDATE calificaciones SET 
                                  periodo1 = ?, periodo2 = ?, periodo3 = ?, periodo4 = ?
                                  WHERE id_estudiante = ? AND id_materia = ?");
        $stmt->bind_param("ddddii", $periodo1, $periodo2, $periodo3, $periodo4, $id_estudiante, $id_materia);
    } else {
        // Insertar nuevo registro
        $stmt = $conexion->prepare("INSERT INTO calificaciones 
                                  (id_curso, id_estudiante, id_materia, periodo1, periodo2, periodo3, periodo4) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiidddd", $id_curso, $id_estudiante, $id_materia, $periodo1, $periodo2, $periodo3, $periodo4);
    }
    
    $stmt->execute();
    
    header("Location: ver_notas.php?id_curso=$id_curso&id_estudiante=$id_estudiante");
    exit();
}

header("Location: ver_notas.php");
?>