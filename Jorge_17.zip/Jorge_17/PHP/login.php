<?php
include 'conexion.php';
session_start();

// Mostrar errores para depuración (quítalo en producción)
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['email']) || empty($_POST['password'])) {
        $_SESSION['error'] = "Debes ingresar el correo y la contraseña";
        header("Location: ../html/login.html");
        exit;
    }

    // Escapar entrada para evitar inyección SQL
    $email = mysqli_real_escape_string($conexion, $_POST['email']);
    $password = $_POST['password'];

    // Consultar la base de datos
    $sql = "SELECT r.id, r.contrasena, COALESCE(rr.id_rol, 3) AS id_rol 
            FROM registro r
            LEFT JOIN rol_registro rr ON r.id = rr.id_registro
            WHERE r.email = '$email'";

    $res = mysqli_query($conexion, $sql);

    if ($res && $user = mysqli_fetch_assoc($res)) {
        if ($password === $user['contrasena']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['id_rol'] = $user['id_rol'];

            // Redirigir según el rol
            switch ($user['id_rol']) {
                case 1: // Admin
                    header("Location: school_admi.php");
                    break;
                case 2: // Docente
                    header("Location: school_profesor.php");
                    break;
                case 3: // Estudiante
                    header("Location: school_estudiante.php");
                    break;
                default:
                    header("Location: ../html/login.html?error=rol_no_valido");
            }            
            
            exit;
        }
    }

    $_SESSION['error'] = "Credenciales incorrectas";
    header("Location: ../html/login.html");
    exit;
}

// Cerrar conexión
mysqli_close($conexion);
?>