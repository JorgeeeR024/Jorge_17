<?php
include 'conexion.php';
session_start();

// Mostrar errores para depuración (quítalo en producción)
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validar campos obligatorios (excepto el curso, se valida después según el rol)
    $camposRequeridos = ['nombre', 'tpdoc', 'numero_doc', 'email', 'contrasena'];
    foreach ($camposRequeridos as $campo) {
        if (empty($_POST[$campo])) {
            $_SESSION['error'] = "Todos los campos son obligatorios";
            header("Location: ../html/registro.html");
            exit;
        }
    }

    // Sanitización de entrada
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $tpdoc = mysqli_real_escape_string($conexion, $_POST['tpdoc']);
    $numero_doc = mysqli_real_escape_string($conexion, $_POST['numero_doc']);
    $email = mysqli_real_escape_string($conexion, $_POST['email']);
    $pass = mysqli_real_escape_string($conexion, $_POST['contrasena']); // ← sin hasheo

    // Asignar rol según el código de invitación
    $codigo = $_POST['codigo_invitacion'] ?? '';
    $rol = ($codigo === 'ADMIN2024') ? 1 : (($codigo === 'DOC2024') ? 2 : 3);

    // Validar y procesar curso
    $id_curso = isset($_POST['id_curso']) ? (int)$_POST['id_curso'] : 0;

    if ($rol === 3 && !in_array($id_curso, [1, 2, 3])) {
        $_SESSION['error'] = "Debes seleccionar un curso válido si eres estudiante.";
        header("Location: ../html/registro.html");
        exit;
    }

    if ($rol !== 3 && $id_curso === 0) {
        $id_curso = "NULL";
    }

    // Insertar usuario en la tabla "registro"
    $sql = "INSERT INTO registro (nombre, tpdoc, numero_doc, email, contrasena, id_curso)
            VALUES ('$nombre', '$tpdoc', '$numero_doc', '$email', '$pass', $id_curso)";

    if (mysqli_query($conexion, $sql)) {
        $user_id = mysqli_insert_id($conexion);

        // Insertar rol
        mysqli_query($conexion, "INSERT INTO rol_registro (id_registro, id_rol) VALUES ($user_id, $rol)");

        $_SESSION['success'] = "Registro exitoso. Ahora inicia sesión.";
        header("Location: ../html/login.html");
        exit;
    } else {
        $_SESSION['error'] = "Error al registrar el usuario: " . mysqli_error($conexion);
        header("Location: ../html/registro.html");
        exit;
    }
}

// Cerrar conexión
mysqli_close($conexion);
?>
