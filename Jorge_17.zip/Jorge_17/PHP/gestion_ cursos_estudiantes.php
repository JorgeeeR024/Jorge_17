<?php
session_start();
include 'conexion.php';

// Verificar rol admin
if (!isset($_SESSION['user_id']) || $_SESSION['id_rol'] != 1) {
    header("Location: ../html/login.html");
    exit;
}

// Consulta estudiantes con sus cursos (usando LEFT JOIN)
$sql = "SELECT 
           r.id, 
           r.nombre, 
           r.email,
           GROUP_CONCAT(DISTINCT c.nombre_grado SEPARATOR ', ') as cursos_asignados
        FROM registro r
        LEFT JOIN estudiantes_cursos ec ON r.id = ec.id_estudiante
        LEFT JOIN cursos c ON ec.id_curso = c.id_curso
        WHERE r.id IN (SELECT id_registro FROM rol_registro WHERE id_rol = 3)
        GROUP BY r.id
        ORDER BY r.nombre";

$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/gestion_cursos_estudiantes.css">
    <title>Gestión de Estudiantes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

</head>
<body>
    <div class="admin-container">
        <!-- Barra de navegación -->
        <nav class="navbar"> 
            <a href="school_admin.php" class="logo">InsSchool</a>
            <ul class="nav-links">
                <li class="user-info">Bienvenido, <strong>Administrador</strong></li>
                <li><a href="../logout.php" class="logout-btn">Cerrar sesión</a></li>
            </ul>
        </nav>

        <div class="container">
            <h1><i class="fas fa-users"></i> Gestión de  notas de Estudiantes</h1>
            
            <?php if (isset($_SESSION['mensaje'])): ?>
                <div class="alert alert-success"><?= $_SESSION['mensaje'] ?></div>
                <?php unset($_SESSION['mensaje']); ?>
            <?php endif; ?>

            <table class="tabla-estudiantes">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th class="cursos-col">Cursos Asignados</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($estudiante = mysqli_fetch_assoc($resultado)): ?>
                    <tr>
                        <td><?= $estudiante['id'] ?></td>
                        <td><?= htmlspecialchars($estudiante['nombre']) ?></td>
                        <td><?= htmlspecialchars($estudiante['email']) ?></td>
                        <td class="cursos-col">
                            <?= $estudiante['cursos_asignados'] ? htmlspecialchars($estudiante['cursos_asignados']) : 'Sin cursos asignados' ?>
                        </td>
                        <td>
                            <a href="editar_curso_estudiante.php?id=<?= $estudiante['id'] ?>" class="btn-editar">
                                <i class="fas fa-edit"></i> Gestionar
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>