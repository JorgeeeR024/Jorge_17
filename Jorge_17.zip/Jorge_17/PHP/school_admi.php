<?php
session_start();

// Verificar si el usuario es Administrador (rol 1)
if (!isset($_SESSION['user_id']) || ($_SESSION['id_rol'] ?? 3) != 1) {
    header("Location: login.html");
    exit;
}

$nombre_rol = "Administrador"; // Forzamos el nombre del rol para este panel
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/InsSchool.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administrador - InsSchool</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <!-- Barra de navegación adaptada para Admin -->
    <nav class="navbar">
        <a href="admin_panel.php" class="logo">InsSchool</a>
        <div class="hamburger">
            <i class="fas fa-bars"></i>
        </div>
        <ul class="nav-links">
            <li><a href="../html/profesores.html">Gestión de Profesores</a></li>
            <li><a href="gestion_estudiantes.php">Gestión de Estudiantes</a></li>
            <li><a href="gestion_%20cursos_estudiantes.php">Cursos LCG</a></li>
            <li><a href="ver_notas.php">Notas (Admin)</a></li>
            <li><a href="../html/sedes/Sedes.html">Sedes</a></li>
            <li><a href="../html/grafico.html">Grafico de registros</a></li>
            <li><a href="../html/grafico_notas.html">Grafico de Notas</a></li>
            <li class="user-info">Bienvenido, <strong><?php echo $nombre_rol; ?></strong></li>
            <li><a href="logout.php" class="logout-btn">Cerrar sesión</a></li>
        </ul>
    </nav>

    <!-- Header con mensaje específico para Admin -->
    <header>
        <div class="header-content">
            <h1>Panel de Administración</h1>
            <p>Control completo del sistema educativo</p>
            <div class="header-buttons">
                <a href="gestion_usuarios.php" class="btn">Administrar Usuarios</a>
                <a href="generar_reportes.php" class="btn btn-outline">Generar Reportes</a>
            </div>
        </div>
    </header>

    <!-- Sección de bienvenida adaptada -->
    <section id="about" class="welcome-section">
        <h2>Herramientas de Administración</h2>
        <p>
            Desde este panel podrás gestionar todos los aspectos académicos, asignar profesores, generar reportes institucionales y configurar el sistema.
        </p>
    </section>

    <!-- Tarjetas interactivas con funcionalidades de Admin -->
    <div class="content">
        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/admin1.jpg" alt="Gestión de Usuarios">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Gestión de Usuarios</h3>
                <p class="card-text">Crea, edita o elimina cuentas de profesores, estudiantes y personal administrativo.</p>
                <a href="gestion_usuarios.php" class="card-btn">Acceder</a>
            </div>
        </div>

        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/admin2.jpg" alt="Reportes Estadísticos">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Reportes</h3>
                <p class="card-text">Genera informes detallados sobre rendimiento académico y asistencia.</p>
                <a href="reportes.php" class="card-btn">Generar</a>
            </div>
        </div>

        <div class="card">
            <div class="card-img-container">
                <img src="../IMG/admin3.jpg" alt="Configuración del Sistema">
                <div class="card-overlay"></div>
            </div>
            <div class="card-content">
                <h3 class="card-title">Configuración</h3>
                <p class="card-text">Personaliza parámetros del sistema, periodos académicos y permisos.</p>
                <a href="configuracion.php" class="card-btn">Configurar</a>
            </div>
        </div>
    </div>

    <!-- Sección de estadísticas con datos relevantes para Admin -->
    <section class="stats-section">
        <div class="stats-container">
            <div class="stat-item">
                <div class="stat-number" id="total-profesores">120</div>
                <div class="stat-text">Profesores registrados</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="total-estudiantes">2,500+</div>
                <div class="stat-text">Estudiantes activos</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="aprobacion-general">96%</div>
                <div class="stat-text">Tasa de aprobación</div>
            </div>
        </div>
    </section>

    <!-- Scripts adicionales para funcionalidades de Admin -->
    <script>
        // Ejemplo: Cargar estadísticas reales via AJAX
        fetch('get_stats.php')
            .then(response => response.json())
            .then(data => {
                document.getElementById('total-profesores').textContent = data.profesores;
                document.getElementById('total-estudiantes').textContent = data.estudiantes;
                document.getElementById('aprobacion-general').textContent = data.aprobacion + '%';
            });
    </script>

</body>
</html> 