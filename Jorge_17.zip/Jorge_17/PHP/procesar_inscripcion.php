<?php
include 'conexion.php';
require('fpdf/fpdf.php');
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Configurar MySQL para UTF-8
mysqli_set_charset($conexion, "utf8mb4");

// Verificar que todos los campos están llenos
if (!isset($_POST['nombre'], $_POST['grado'], $_POST['acudiente'], $_POST['telefono'], $_POST['email']) ||
    empty($_POST['nombre']) || empty($_POST['grado']) || empty($_POST['acudiente']) || empty($_POST['telefono']) || empty($_POST['email'])) {
    die("Completa todos los campos.");
}

// Escapar variables para evitar inyección SQL
$nombre    = mysqli_real_escape_string($conexion, trim($_POST['nombre']));
$grado     = mysqli_real_escape_string($conexion, trim($_POST['grado']));
$acudiente = mysqli_real_escape_string($conexion, trim($_POST['acudiente']));
$telefono  = mysqli_real_escape_string($conexion, trim($_POST['telefono']));
$email     = mysqli_real_escape_string($conexion, trim($_POST['email']));

// Insertar en la base de datos
$sql = "INSERT INTO inscripciones (nombre, grado, acudiente, telefono, email) 
        VALUES ('$nombre', '$grado', '$acudiente', '$telefono', '$email')";

if (!mysqli_query($conexion, $sql)) {
    die("Error al guardar los datos.");
}

// Crear PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, iconv('UTF-8', 'ISO-8859-1', 'Solicitud de Inscripción'), 0, 1, 'C');
$pdf->Ln(10);

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, iconv('UTF-8', 'ISO-8859-1', "Nombre: $nombre"), 0, 1);
$pdf->Cell(0, 10, iconv('UTF-8', 'ISO-8859-1', "Grado: $grado"), 0, 1);
$pdf->Cell(0, 10, iconv('UTF-8', 'ISO-8859-1', "Acudiente: $acudiente"), 0, 1);
$pdf->Cell(0, 10, iconv('UTF-8', 'ISO-8859-1', "Teléfono: $telefono"), 0, 1);
$pdf->Cell(0, 10, iconv('UTF-8', 'ISO-8859-1', "Email: $email"), 0, 1);

// Guardar el PDF en un archivo temporal
$pdfFilePath = tempnam(sys_get_temp_dir(), 'inscripcion_') . '.pdf';
$pdf->Output('F', $pdfFilePath);

// Enviar el PDF por correo electrónico
$mail = new PHPMailer(true);

try {
    // Configuración del servidor SMTP
    $mail->isSMTP();
    $mail->CharSet = 'UTF-8';
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'notificacionessena2025@gmail.com';
    $mail->Password = 'smxc mfdy qurb xjfy'; // ⚠️ Usa una variable segura en producción
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Remitente y destinatario
    $mail->setFrom('notificacionessena2025@gmail.com', 'Inscripciones SENA');
    $mail->addAddress($email, $nombre);

    // Adjuntar el PDF
    $mail->addAttachment($pdfFilePath, 'Inscripcion.pdf');

    // Contenido del correo
    $mail->isHTML(true);
    $mail->Subject = mb_encode_mimeheader('Solicitud de Inscripción', 'UTF-8', 'B');
    $mail->Body    = "<p>Hola, IED, Luis Carlos Galan, me llamo <b>" . htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8') . "</b>,</p><p>Adjunto encontrarás la solicitud de inscripción.</p>";
    $mail->AltBody = "Hola $nombre,\n\nAdjunto encontrarás la solicitud de inscripción.";

    if ($mail->send()) {
        echo "Inscripción exitosa. Revisa tu correo.";
    } else {
        error_log("Error al enviar el correo: " . $mail->ErrorInfo);
        echo "Hubo un problema al enviar el correo. Contacta con soporte.";
    }

} catch (Exception $e) {
    error_log("Excepción de PHPMailer: " . $e->getMessage());
    echo "Error en el envío del correo. Contacta con soporte.";
}

// Eliminar el archivo temporal
unlink($pdfFilePath);

// Cerrar conexión a la base de datos
mysqli_close($conexion);
?>
