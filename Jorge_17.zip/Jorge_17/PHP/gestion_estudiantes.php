<?php
session_start();
include 'conexion.php';

// Verificar autenticación y rol
if (!isset($_SESSION['user_id']) || ($_SESSION['id_rol'] != 1)) {
    header("Location: ../html/login.html");
    exit;
}

// Procesar eliminación si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['eliminar'])) {
    $id = $_POST['id_estudiante'];
    
    // Primero eliminamos de la tabla rol_registro
    $sql_delete_rol = "DELETE FROM rol_registro WHERE id_registro = $id AND id_rol = 3";
    mysqli_query($conexion, $sql_delete_rol);
    
    // Luego eliminamos de la tabla registro
    $sql_delete = "DELETE FROM registro WHERE id = $id";
    
    if (mysqli_query($conexion, $sql_delete)) {
        $_SESSION['mensaje'] = "Estudiante eliminado correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
        header("Location: gestion_estudiantes.php");
        exit;
    } else {
        $_SESSION['mensaje'] = "Error al eliminar estudiante: " . mysqli_error($conexion);
        $_SESSION['tipo_mensaje'] = "error";
    }
}

// Consulta para obtener estudiantes
$sql = "SELECT r.id, r.nombre, r.email, r.fecha_registro 
        FROM registro r
        WHERE r.id IN (SELECT id_registro FROM rol_registro WHERE id_rol = 3)
        ORDER BY r.fecha_registro DESC";
        
$resultado = mysqli_query($conexion, $sql);

if (!$resultado) {
    die("Error en la consulta: " . mysqli_error($conexion));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/gestion_estudiantes.css">
    <title>Gestión de Estudiantes</title>
    <style>
        /* [Mantén los mismos estilos CSS que antes] */
    </style>
</head>
<body>
    <!-- Barra de navegación -->
    <nav class="navbar">
        <a href="school_admin.php" class="logo">InsSchool</a>
        <ul class="nav-links">
            <li class="user-info">Bienvenido, <strong>Administrador</strong></li>
            <li><a href="logout.php" class="logout-btn">Cerrar sesión</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Gestión de Estudiantes</h1>
        
        <?php if (isset($_SESSION['mensaje'])): ?>
    <div class="mensaje <?php echo isset($_SESSION['tipo_mensaje']) ? $_SESSION['tipo_mensaje'] : ''; ?>">
        <?php 
        echo $_SESSION['mensaje']; 
        unset($_SESSION['mensaje']);
        unset($_SESSION['tipo_mensaje']);
        ?>
    </div>
<?php endif; ?>

        
        <table class="tabla-estudiantes">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Fecha Registro</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while($estudiante = mysqli_fetch_assoc($resultado)): ?>
                <tr>
                    <td><?= $estudiante['id'] ?></td>
                    <td><?= htmlspecialchars($estudiante['nombre']) ?></td>
                    <td><?= htmlspecialchars($estudiante['email']) ?></td>
                    <td><?= date('d/m/Y', strtotime($estudiante['fecha_registro'])) ?></td>
                    <td class="acciones">
                        <a href="editar_gestion_estudiantes.php?id=<?= $estudiante['id'] ?>" class="btn-editar">Editar</a>
                        
                        <!-- Formulario para eliminar -->
                        <form method="POST" action="gestion_estudiantes.php" style="display: inline;">
                            <input type="hidden" name="id_estudiante" value="<?= $estudiante['id'] ?>">
                            <button type="submit" name="eliminar" class="btn-eliminar" 
                                    onclick="return confirm('¿Estás seguro de eliminar este estudiante?')">
                                Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>