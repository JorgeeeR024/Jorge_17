<?php
$conexion = mysqli_connect("localhost", "root", "", "ied_luis_carlos_galan");
if (!$conexion) {
    die("Problemas con la conexión: " . mysqli_connect_error());
}
?>