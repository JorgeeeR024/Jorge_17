<?php
include('conexion.php');

// Obtener datos de la nota
$id = intval($_GET['id']);
$nota = $conexion->query("SELECT c.*, r.nombre AS estudiante, m.nombre AS materia 
                         FROM calificaciones c
                         JOIN registro r ON c.id_estudiante = r.id
                         JOIN materias m ON c.id_materia = m.id_materia
                         WHERE c.id = $id")->fetch_assoc();

if(!$nota) {
    header("Location: ver_notas.php");
    exit();
}

// Procesar actualización
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $periodo1 = floatval($_POST['periodo1'] ?? 0);
    $periodo2 = floatval($_POST['periodo2'] ?? 0);
    $periodo3 = floatval($_POST['periodo3'] ?? 0);
    $periodo4 = floatval($_POST['periodo4'] ?? 0);
    
    $stmt = $conexion->prepare("UPDATE calificaciones SET 
                              periodo1 = ?, periodo2 = ?, periodo3 = ?, periodo4 = ?
                              WHERE id = ?");
    $stmt->bind_param("ddddi", $periodo1, $periodo2, $periodo3, $periodo4, $id);
    $stmt->execute();
    
    header("Location: ver_notas.php?id_curso=".$nota['id_curso']."&id_estudiante=".$nota['id_estudiante']);
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Notas</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { max-width: 500px; margin: 0 auto; }
        .form-group { margin-bottom: 15px; }
        label { display: inline-block; width: 120px; }
        input { width: 80px; padding: 8px; }
        button { padding: 10px 15px; background: #4CAF50; color: white; border: none; }
    </style>
</head>
<body>
    <h1>Editar Notas</h1>
    <h3>Estudiante: <?= $nota['estudiante'] ?></h3>
    <h3>Materia: <?= $nota['materia'] ?></h3>
    
    <form method="POST">
        <div class="form-group">
            <label>Periodo 1:</label>
            <input type="number" name="periodo1" value="<?= $nota['periodo1'] ?? 0 ?>" step="0.1" min="0" max="10">
        </div>
        
        <div class="form-group">
            <label>Periodo 2:</label>
            <input type="number" name="periodo2" value="<?= $nota['periodo2'] ?? 0 ?>" step="0.1" min="0" max="10">
        </div>
        
        <div class="form-group">
            <label>Periodo 3:</label>
            <input type="number" name="periodo3" value="<?= $nota['periodo3'] ?? 0 ?>" step="0.1" min="0" max="10">
        </div>
        
        <div class="form-group">
            <label>Periodo 4:</label>
            <input type="number" name="periodo4" value="<?= $nota['periodo4'] ?? 0 ?>" step="0.1" min="0" max="10">
        </div>
        
        <button type="submit">Guardar Cambios</button>
        <a href="ver_notas.php?id_curso=<?= $nota['id_curso'] ?>&id_estudiante=<?= $nota['id_estudiante'] ?>">Cancelar</a>
    </form>
</body>
</html>