<?php
session_start();
include 'conexion.php';

// Verificar autenticación y rol
if (!isset($_SESSION['user_id']) || ($_SESSION['id_rol'] != 1)) {
    header("Location: ../html/login.html");
    exit;
}

// Obtener datos del estudiante
$id = $_GET['id'];
$sql = "SELECT * FROM registro WHERE id = $id";
$resultado = mysqli_query($conexion, $sql);
$estudiante = mysqli_fetch_assoc($resultado);

// Procesar actualización
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $email = mysqli_real_escape_string($conexion, $_POST['email']);
    
    $sql_update = "UPDATE registro SET nombre = '$nombre', email = '$email' WHERE id = $id";
    
    if (mysqli_query($conexion, $sql_update)) {
        $mensaje = "Estudiante actualizado correctamente";
        // Actualizar datos mostrados
        $estudiante['nombre'] = $nombre;
        $estudiante['email'] = $email;
    } else {
        $error = "Error al actualizar estudiante: " . mysqli_error($conexion);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Estudiante</title>
    <style>
        /* Estilos similares al archivo principal */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .navbar {
            background-color: #2c3e50;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            color: white;
            text-decoration: none;
            font-size: 24px;
            font-weight: bold;
        }
        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
        }
        .logout-btn {
            background-color: #e74c3c;
            padding: 8px 15px;
            border-radius: 5px;
        }
        .container {
            max-width: 600px;
            margin: 30px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        .btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #2980b9;
        }
        .mensaje {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }
        .exito {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="school_admin.php" class="logo">InsSchool</a>
        <ul class="nav-links">
            <li class="user-info">Bienvenido, <strong>Administrador</strong></li>
            <li><a href="../../logout.php" class="logout-btn">Cerrar sesión</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Editar Estudiante</h1>
        
        <?php if (isset($mensaje)): ?>
            <div class="mensaje exito"><?php echo $mensaje; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="mensaje error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($estudiante['nombre']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($estudiante['email']) ?>" required>
            </div>
            
            <button type="submit" class="btn">Guardar Cambios</button>
            <a href="gestion_estudiantes.php" style="margin-left: 10px;">Volver</a>
        </form>
    </div>
</body>
</html>