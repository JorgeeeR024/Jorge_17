function validarFormulario() {
    /* Capturar los datos del formulario por ID */
    const nombre = document.getElementById('nombre');
    const tpdoc = document.getElementById('tpdoc');
    const numero_doc = document.getElementById('numero_doc');
    const email = document.getElementById('email');
    const contrasena = document.getElementById("contrasena");

    /* div para mostrar los errores */
    const div = document.createElement("DIV");
    div.classList.add("error");
    const formulario = document.getElementById("formulario");

    /* Eliminar espacios en blanco */
    const nombreValor = nombre.value.trim();
    const tpdocValor = tpdoc.value;
    const numeroDocValor = numero_doc.value.trim();
    const emailValor = email.value.trim();
    const contrasenaValor = contrasena.value.trim();

    // Validar nombres (solo letras y espacios)
    if (!/^[A-Za-z\s]+$/.test(nombreValor)) {
        div.textContent = 'El nombre solo debe contener letras y espacios.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        nombre.focus();
        return false;
    }

    // Validar selección de tipo de documento
    if (tpdocValor === "") {
        div.textContent = 'Por favor, selecciona un tipo de documento.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        tpdoc.focus();
        return false;
    }

    // Validar número de documento (solo números, 7 a 10 dígitos)
    if (!/^\d{7,10}$/.test(numeroDocValor)) {
        div.textContent = 'El número de documento debe tener entre 7 y 10 dígitos numéricos.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        numero_doc.focus();
        return false;
    }

    // Validar formato de correo electrónico
    if (!/^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,7}$/.test(emailValor)) {
        div.textContent = 'El formato del correo electrónico no es válido.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        email.focus();
        return false;
    }

    // Validar contraseña (mínimo 6 caracteres)
    if (contrasenaValor.length < 6) {
        div.textContent = 'La contraseña debe tener al menos 6 caracteres.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        contrasena.focus();
        return false;
    }

    return true; // Permitir el envío del formulario si todas las validaciones pasan
}
