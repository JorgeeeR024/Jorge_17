function validarFormulario() {
    /* Capturar los datos del formulario por ID */
    const nombre = document.getElementById('nombre');
    const grado = document.getElementById('grado');
    const acudiente = document.getElementById('acudiente');
    const telefono = document.getElementById('telefono');
    const email = document.getElementById("email");

    /* div para mostrar los errores */
    const div = document.createElement("DIV");
    div.classList.add("error");
    const formulario = document.getElementById("formulario");

    /* Eliminar espacios en blanco */
    const nombreValor = nombre.value.trim();
    const gradoValor = grado.value;
    const acudienteValor = acudiente.value.trim();
    const telefonoValor = telefono.value.trim();
    const emailValor = email.value.trim();

    // Validar nombres (solo letras y espacios)
    if (!/^[A-Za-z\s]+$/.test(nombreValor)) {
        div.textContent = 'El nombre solo debe contener letras y espacios.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        nombre.focus();
        return false;
    }

    if (!/^[A-Za-z\s]+$/.test(acudienteValor)) {
        div.textContent = 'El nombre del acudiente  solo debe contener letras y espacios.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        acudiente.focus();
        return false;
    }

    // Validar selección de tipo de grado
    if (gradoValor === "") {
        div.textContent = 'Por favor, selecciona un grado valido.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        tpdoc.focus();
        return false;
    }

    // Validar número telefonico (solo números, 7 a 10 dígitos)
    if (!/^\d{10,10}$/.test(telefonoValor)) {
        div.textContent = 'El número telefonico debe de tener 10 digitos.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        numero_doc.focus();
        return false;
    }

    // Validar formato de correo electrónico
    if (!/^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,7}$/.test(emailValor)) {
        div.textContent = 'El formato del correo electrónico no es válido.';
        formulario.insertBefore(div, formulario.firstChild);
        setTimeout(() => div.style.display = "none", 5000);
        email.focus();
        return false;
    }

    // Validar contraseña (mínimo 6 caracteres)


    return true; // Permitir el envío del formulario si todas las validaciones pasan
}
