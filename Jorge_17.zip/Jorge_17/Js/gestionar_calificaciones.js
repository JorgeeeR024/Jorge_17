document.addEventListener("DOMContentLoaded", mostrarDatos);

document.querySelector("#formulario").addEventListener("submit", function(e) {
    e.preventDefault();
    let data = new FormData(this);
    data.append("accion", "guardar");
    fetch("gestionar_calificaciones.php", { method: "POST", body: data })
        .then(() => mostrarDatos())
        .then(() => this.reset());
});

function mostrarDatos() {
    fetch("gestionar_calificaciones.php")
        .then(res => res.json())
        .then(data => {
            const divpunta = document.querySelector("#divpunta");
            divpunta.innerHTML = data.map(grado => `
                <p>${grado.nombre} - ${grado.materia} - P1: ${grado.periodo1} P2: ${grado.periodo2}
                    <button onclick="editar(${grado.id}, '${grado.nombre}')">Editar</button>
                    <button onclick="eliminar(${grado.id})">Eliminar</button>
                </p>
            `).join('');
        });
}

function editar(id, nombre) {
    document.querySelector("#formulario").elements["nombre"].value = nombre;
    document.querySelector("#formulario").onsubmit = function(e) {
        e.preventDefault();
        let data = new FormData(this);
        data.append("accion", "editar");
        data.append("id", id);
        fetch("gestionar_calificaciones.php", { method: "POST", body: data })
            .then(() => mostrarDatos());
    };
}

function eliminar(id) {
    fetch("gestionar_calificaciones.php", {
        method: "POST",
        body: new URLSearchParams({ accion: "eliminar", id })
    }).then(() => mostrarDatos());
}
