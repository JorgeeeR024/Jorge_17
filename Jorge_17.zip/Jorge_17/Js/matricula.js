document.addEventListener("DOMContentLoaded", function() {
    cargarDatos();
    mostrarDatos();
});

let datos = [];

// Cargar datos del LocalStorage al iniciar la página
function cargarDatos() {
    if (localStorage.getItem("datos") !== null) {
        datos = JSON.parse(localStorage.getItem("datos"));
    }
}

// Guardar información del formulario
function guardarinformacion() {
    let formulario = document.querySelector("#formulario");

    formulario.addEventListener("submit", function(event) {
        event.preventDefault();
        
        let formuDatos = new FormData(formulario);
        let nombre = formuDatos.get("nombre").trim();
        let grado = formuDatos.get("grado").trim();

        // Validar que los campos no estén vacíos
        if (nombre !== "" && grado !== "") {
            datos.push({
                nombre: nombre,
                grado: grado
            });

            localStorage.setItem("datos", JSON.stringify(datos));
            mostrarDatos();
            formulario.reset();
        } else {
            alert("Por favor, completa todos los campos.");
        }
    });
}

// Mostrar los datos en pantalla
function mostrarDatos() {
    let divpunta = document.querySelector("#divpunta");
    divpunta.innerHTML = "";

    datos.forEach((dato, index) => {
        let p = document.createElement("p");
        let botonEditar = document.createElement("button");
        let botonEliminar = document.createElement("button");

        p.textContent = `Número: ${index + 1} - Nombre: ${dato.nombre} - Grado: ${dato.grado}`;
        
        // Botón para editar
        botonEditar.textContent = "Editar";
        botonEditar.onclick = () => editarDatos(index);

        // Botón para eliminar
        botonEliminar.textContent = "Eliminar";
        botonEliminar.onclick = () => eliminarDatos(index);

        p.appendChild(botonEditar);
        p.appendChild(botonEliminar);
        divpunta.appendChild(p);
    });
}

// Editar datos
function editarDatos(index) {
    let formulario = document.querySelector("#formulario");
    let editarD = document.querySelector("#editarD");
    
    formulario.elements["nombre"].value = datos[index].nombre;
    formulario.elements["grado"].value = datos[index].grado;

    editarD.disabled = false;

    editarD.onclick = () => {
        let nombreEditado = formulario.elements["nombre"].value.trim();
        let gradoEditado = formulario.elements["grado"].value.trim();

        // Validar que los campos no estén vacíos
        if (nombreEditado !== "" && gradoEditado !== "") {
            datos[index].nombre = nombreEditado;
            datos[index].grado = gradoEditado;

            localStorage.setItem("datos", JSON.stringify(datos));
            mostrarDatos();
            formulario.reset();
            editarD.disabled = true;
        } else {
            alert("Por favor, completa todos los campos para editar.");
        }
    };
}

// Eliminar datos
function eliminarDatos(index) {
    datos.splice(index, 1);
    localStorage.setItem("datos", JSON.stringify(datos));
    mostrarDatos();
}
